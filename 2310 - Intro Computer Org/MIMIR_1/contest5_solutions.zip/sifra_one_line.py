print(len(set(''.join(d if d.isdigit() else ' ' for d in input()).split())))
