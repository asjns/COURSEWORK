#include <stack>
#include <iostream>
using namespace std;

int n, sol;

int main() {
    ios::sync_with_stdio(false);
    cin >> n;
    stack<int> s;
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        while (!s.empty() && s.top() > x)
            s.pop();
        if (!s.empty() && s.top() == x)
            continue;
        if (x != 0) {
            sol++;
            s.push(x);
        }
    }
    cout << sol << endl;
    return 0;
}
